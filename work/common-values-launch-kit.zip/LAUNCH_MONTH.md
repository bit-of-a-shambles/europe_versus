# Common Values launch month

The launch is built around four American misconceptions about Europe. Each edition corrects the lazy version of the claim, concedes the part the evidence supports, and ends with a practical European reform question. Every post contains one chart, 300–600 words, phone-safe labels, methodology, alt text, exact CSV data and distinct Substack preview copy.

| Issue | Date | Post | Chart | The correction | Status |
| ---: | --- | --- | --- | --- | --- |
| 01 | 4 Sep 2026 | Europe's income growth moved east | Ranked bars, 26 EU countries | Europe did grow, but the strongest household gains happened outside the western capitals | Website lead |
| 02 | 11 Sep 2026 | The productivity gap is real. The lazy-European story is not. | Ranked bars, full OECD figure | The EU average trails the US; several European economies already work at the frontier | Unpublished draft |
| 03 | 18 Sep 2026 | Europe's innovation problem begins after the patent | Ranked bars, EPO applications | Europe produces inventions; its larger failure is financing and scaling firms | Unpublished draft |
| 04 | 25 Sep 2026 | Europe met the 2% defence target. Spending isn't strategy. | Annual line, 2014–2025 | Burden-sharing improved sharply; procurement and industrial capacity are the next test | Unpublished draft |

## Preview text

1. The stagnation story misses the largest income gains in the European Union.
2. Europe works fewer hours. That does not mean every European hour produces less.
3. Europe does not lack invention. It loses too much ground between invention and scale.
4. The old spending argument is ending. The harder argument is about what Europe buys.

## Draft workflow

The task below creates a reviewable Substack draft and does not publish it:

```bash
PUBLIC_BASE_URL=https://commonvalues.eu \
SUBSTACK_API_URL=https://interessant3.substack.com/api/v1 \
bin/rails "editions:substack_draft[2026-09-04-europes-income-growth-moved-east]"
```

Repeat with the other three slugs in `content/editions`. The task creates the title, subtitle, opening paragraph, phone-first chart image, remaining reporting, source section and subscribe widget. It prints the preview text for manual placement because the current Substack library does not expose that field.

## Publication gate

- Run `bin/rails runner analysis/launch_month/verify.rb`.
- Review the web chart and exported image at 320px, 360px and 390px.
- Check each source and methodology link.
- Paste the preview text into Substack.
- Send a test email and inspect it on a physical phone.
- Publish only after editorial approval; all four Substack posts remain drafts until then.
